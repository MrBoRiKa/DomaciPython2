

def skratiti(str):
    if len(str) > 30:
        print(str[0:30] + '...')
    else:
        print('Tekst je manji ili jednak 30 karaktera')

skratiti("Romani napadajteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee")