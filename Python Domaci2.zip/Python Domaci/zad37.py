
def izracunati_bod(string):
    lista = []
    k = 1
    nula = 0
    zvezda = -1
    priv = 0
    for i in string:
        if i == k:
            lista.append('1')
        elif i == nula:
            lista.append('0')
        elif i == zvezda:
            lista.append('-1')
    print(lista)
    return lista

        
izracunati_bod('1110')