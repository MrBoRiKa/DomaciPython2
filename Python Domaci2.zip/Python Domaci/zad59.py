

def makeitbin(string):
    pretvoreni = ""
    
    if not len(string) > 9:
        for i in string:
            if int(i) % 2 == 0:

                pretvoreni += '0'
            else:
                pretvoreni += '1'
    else:
        print('Unijeli ste preko 9 cifara')
    print(pretvoreni)

makeitbin('123401242')