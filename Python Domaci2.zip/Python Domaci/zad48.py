

def stepenovanje(broj,stepen):
    privr_stepen = 1
    
    for i in range(stepen): 
        privr_stepen *= broj

    
    return privr_stepen

rezultat =stepenovanje(5,3)
print(rezultat)