


def maks_h2o(h,o):
    max_h20 = min(h//2,o)
    return max_h20

h = 7
o = 8

print(maks_h2o(h,o))