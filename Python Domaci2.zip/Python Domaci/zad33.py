def sum_dig(number):
        return sum(int(digit) for digit in str(number))