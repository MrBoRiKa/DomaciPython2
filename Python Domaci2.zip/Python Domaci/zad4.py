
def kucni_red(time):
    list =[6,13,17,22]
    if list[0]< time <list[1] or list[2]<time < list[3]:
            print('Mozete da radite bucnije radove.')
    else:
          print('Ne mozete da radite bucnije radove.')
kucni_red(15)
