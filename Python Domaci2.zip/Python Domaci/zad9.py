# Moramo da postavimo koordinate prozora i zavjese

x1,y1 =5,5 #Gornji lijevi ugao zavjese
x2,y2 = 2   ,3 #donji desni ugaoa zavjese

#Sada kreiramo varijable za koordinate od prozora
z1,s1 = 2,2 #Ista stvar kako sa zavjesama tako i sa prozorima 
z2,s2 = 3,4 

if x1> z1 and y1 > s1 and x2 <= z2 and y2 <= s2 :
    print("Zavjesa je veca od prozora.")
else:
    print('Nije veca od prozora.')