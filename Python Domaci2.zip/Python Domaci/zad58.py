

string = "Hi Mr. Rober53. How are you today? Today is 08.10.2019"

string2 = ""
for i in string:
        if not i.isdigit():
            string2 += i


print(string2)
    

