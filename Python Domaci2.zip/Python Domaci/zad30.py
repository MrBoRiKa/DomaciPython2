


def calculate1():
    n = int(input('Unesite do koliko da racuna: '))
    x =  range(1,n)
    lista_parnih = []
    lista_neparnih = []
    if x % 2 == 0:
        lista_parnih.append(x)
    elif x %  2 != 0:
        lista_neparnih.append(x)




        
calculate1()
