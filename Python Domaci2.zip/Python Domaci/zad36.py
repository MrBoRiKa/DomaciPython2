
def make_it_binary():
    s = input('Unesite tekst: ') 
    samoglasnik = ['a','e','i','o','u']
    suglasnik = ['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z']
    lista = []
    for i in s:
        if i in suglasnik:
            lista.append('0')
        elif i in samoglasnik:
            lista.append('1')
    
    joined = "".join(lista)
    print(joined)

make_it_binary()

