
def is_in_rectangle(x1,x2):
        
    glx1,glx2 = 5,5
    dlx1,dlx2 = 0,0

    if (x1 or x2 >glx1 and glx2) or (x1 or x2< dlx1 and dlx2):
        print(f'Tacka je van pravougaonika.')
    elif (x1 or x2 == glx1 or glx2) or(x1 or x2 == dlx1 and dlx2):
        print(f'Tacka je unutar pravougaonika.')
    else:
        print(f'Tacka je unutra pravougaonika.')

is_in_rectangle(5,3)