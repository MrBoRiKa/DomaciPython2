

def sum_them(list,start,stop):
    tren_list = []
    for i in list[start:stop]:
        if i % 3 == 0 and i % 6 != 0:
            tren_list.append(i)
            
    print(sum(tren_list))


sum_them([1,2,3,4,5,6,7,8,9,10,11,12,13],1,9)