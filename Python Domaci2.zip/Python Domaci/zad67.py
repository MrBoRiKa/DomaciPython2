

def check_numpos(number_list,number):
    counter = 0
    for i in number_list:
        if i == number:
            counter += 1
    print(counter)


check_numpos([1,2,3,2,1,2,3,4,5,4],2)