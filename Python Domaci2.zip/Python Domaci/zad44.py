def max_visits(lista_posjeta):
    maximum_posjeta = 0 
    dan = ''
    for day, visits in lista_posjeta.items():
        if visits > maximum_posjeta:
            maximum_posjeta = visits
            dan = day 
                
    print(f"Najvise posjeta je bilo u {dan} sa {maximum_posjeta} posjeta")


max_visits({"mon":90,"tue":200,"wed":150,"thu":210,"fri":900,"sat":550,"sun":390})