d = int(input('Unesite duzinu terase u metrima: '))
n = int(input('Unesite kolicinu stubova: '))
s = int(input('Unesite sirinu stubova u centimetrima: '))

r = round(((n*s)-(d*100)) / (-(n+1)), 2)

print( r)