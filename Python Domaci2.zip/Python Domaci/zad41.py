



def get_max(lista,max_n):
    lista_ispod_max = []
    for number in lista:
        if number < max_n:
            lista_ispod_max.append(number)
        else:
            pass
    print(lista_ispod_max)
    return lista_ispod_max


get_max([1,2,3,4,-2,-3,5],3)