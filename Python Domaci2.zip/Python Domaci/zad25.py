
def del_z_p(tekst):
    novi_tekst = tekst[1:-1]
    print(novi_tekst)

del_z_p('Rumuni napadajteeeeeeeeasdasd')