
def bigger_paycheck_counter(lista_plata):
    average = sum(lista_plata[1:]) / len(lista_plata)
    bigger_paycheck = 0
    for plata in lista_plata:
        if plata > average:
            bigger_paycheck += 1
    print(f'Broj ljudi koji imaju vecu platu je : {bigger_paycheck} ')

lista_plata = [100,200,300,400,300,500,600,700,200]
bigger_paycheck_counter(lista_plata)
#Prosjecna plata ovog programa je 366.66

