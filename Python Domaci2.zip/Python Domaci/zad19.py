def iznos_skolarine(skolarina,prosjecna_ocjena,nagrada):
    if prosjecna_ocjena >4.5 :
        skolarina1 =skolarina * 0.4
        skolarina = skolarina - skolarina1
        print(f'Vasa skolarina je {skolarina} ')
    elif prosjecna_ocjena > 3.5 and prosjecna_ocjena < 4.5 and nagrada > 0:
        skolarina1 = skolarina *0.3
        skolarina = skolarina - skolarina1
        print(f'Vasa skolarina je {skolarina}')
    elif prosjecna_ocjena >3.5 and prosjecna_ocjena <4.5 and nagrada == 0:
        skolarina1 = skolarina *0.2
        skolarina = skolarina - skolarina1

        print(f'Vasa skolarina je {skolarina}')
    elif prosjecna_ocjena > 2.5 and prosjecna_ocjena < 3.5 and nagrada > 0:
        skolarina1= skolarina * 0.3
        skolarina = skolarina - skolarina1 
        print(f'Vasa skolarina je {skolarina}')
    else:
        skolarina1 = skolarina * 0.1
        skolarina = skolarina - skolarina1
        print(f'Vasa skolarina je {skolarina}')

iznos_skolarine(1800,4.3,1)