# Dat je string sastavljen od karaktera 0 i 1. Karakter 0 predstavlja slobodno polje, a 1
#  predstavlja zauzeto polje. Vaš zadatak je da za zadatu poziciju u stringu provjerite da li
#  su susjedna polja slobodna (lijevo i desno). Napomena: za prvo polje gledate same
#  desno polje, za poslednje polje samo lijevo polje, a za ostala i lijevo i desno polje. Npr.
#  ako je string 01010, a zadata pozicija 2 (indeksiranje kreće od nule), treba štampati 0 jer
#  nema slobodnih polja


# Funkcija za provjeru susjednih slobodnih polja
def provjeri_susjedna_polja(string, pozicija):
    if pozicija == 0:
        return string[pozicija + 1] == '0'
    elif pozicija == len(string) - 1:
        return string[pozicija - 1] == '0'
    else:
        return string[pozicija - 1] == '0' and string[pozicija + 1] == '0'

# Ulazni podaci
string = "01010"
zadata_pozicija = 2

# Provjera susjednih slobodnih polja za zadanu poziciju
if provjeri_susjedna_polja(string, zadata_pozicija):
    print("0")
else:
    print("1")