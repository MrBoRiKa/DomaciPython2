
def is_digit(string):
    lista = []
    for i in string:
       if i.isdigit():
        lista.append(i)
    
    joined = ''.join(lista)
    print(joined)
    return lista


is_digit('\'Hi Mr.Rober53. How are you today? Today is 08.10.2019\'')