def print_to_needed(string,length):
    if len(string)> length:
        print(string[:length] + '...')
    else:
        print(string + '...')


print_to_needed('crnac',10)