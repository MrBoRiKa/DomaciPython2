# Input - Peter's sum
peters_sum = int(input())

# Calculate the number of goals
total_goals = peters_sum // 2

# Output the number of goals
print(total_goals)