
def check_two_three_digit(number_list):
    lista_troc = 0
    lista_dvoc = 0
    for i in number_list:

        if i // 100 != 0:
            lista_troc += 1
        elif i % 10 != 0 :
            lista_dvoc += 1    
        

        
    print(lista_dvoc)
    print(lista_troc)

check_two_three_digit([19,29,399,48,588,231,56])