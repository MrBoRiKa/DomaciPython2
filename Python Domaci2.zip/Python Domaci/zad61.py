

def check_if_alpha(string):
    string2 = ""
    for i in string:
        if i.isupper():
            string2 += i
    print(string2)


check_if_alpha('Black Man chasing you ')