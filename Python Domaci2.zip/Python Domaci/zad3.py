

def check_att(num_pred,num_stud,sem_rad): 
    
    if num_stud > (num_pred * 0.75) and sem_rad == 1:
        print('Moze pristupiti ispitu')
    else:
        print('Ne moze pristupiti ispitu')

check_att(120,100,1)



