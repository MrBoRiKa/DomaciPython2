
def uvecati_vece_plate(lista_plati):
    average = sum(lista_plati) / len(lista_plati)
    counter = 0
    novalista_plati = []
    for i in lista_plati:
        if i > average :
            novalista_plati.append(i + (i* 0.1))
        elif i < average:
            novalista_plati.append(i - (i*0.1))
    for i in novalista_plati:
        if i > average:
            counter += 1


    print (novalista_plati,counter)

uvecati_vece_plate([100,200,300,200,300,400,500,100,200])
    
