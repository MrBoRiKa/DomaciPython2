



def popust_proizvoda(directory_products,popust):
    lista_spustenih_cijena = {}
    dec_popust = popust / 100
    for product,price in directory_products.items():
        cijena_popusta = price * dec_popust
        cijena =price - cijena_popusta
        lista_spustenih_cijena[str(product)] = cijena
    zarada_sa_popustom = sum(lista_spustenih_cijena.values())
    print(f'Vasa krajnja zarada je {format(zarada_sa_popustom,".2f")}' )




popust_proizvoda({"apple": 1.00, "banana": 0.75, "kiwi": 2.50,"black dog": 20,"laptop": 200,"roses":10},20)