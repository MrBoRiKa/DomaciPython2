

def check_target(string,target):
    if string.endswith(target): # Metoda za string
        print('Da')
    else: 
        print('Ne')


check_target('google.me','me')
check_target('yahoo.com','mi')



def check_target2(string,target):
    if target in string[-2:]: # Ovo je samo ako se target dug 2 karaktera .
        print('Da')
    else:print('Ne')

check_target2('Google.me','me')
check_target2('yahoo.com','mi')
