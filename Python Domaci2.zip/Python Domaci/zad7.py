def provjeri_pobjednika(matematika,programiranje,matematika2,programiranje2):
    provjeri_tak1= matematika+programiranje
    provjeri_tak2= matematika2+programiranje2
    if provjeri_tak1 > provjeri_tak2:
        print('Pobjednik je Takmicar 1')

    elif programiranje> programiranje2:
        print('Pobjednik je Takmicar 1')
    
    elif programiranje<programiranje2:
        print('Pobjednik je Takmicar 2')

    else:
        print('Nerijeseno ,jer oba takmicara imaju isto poena iz oba predmeta')

provjeri_pobjednika(20,30,15,35)
provjeri_pobjednika(10,40,20,30)
provjeri_pobjednika(20,30,20,30)