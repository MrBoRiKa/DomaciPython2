# Napisati program koji na osnovu varijabli a, pre, sub i num dodaje prefiks pre, i sufiks suf
#  stringu a num puta i vraća novi prošireni string.
#  Input 1: a = ‘test’, pre = ‘pr’, suf = ‘su’, num = 2;
#  Output 1: ‘prprtestsusu’


def add_prefix_suffix(a, pre, suf, num):
    # Create the new string with the prefix and suffix added
    new_string = pre + a + suf
    
    # Add the prefix and suffix to the new string the specified number of times
    for i in range(num - 1):
        new_string = pre + new_string + suf
        
    return new_string
# Example usage
a = 'test'
pre = 'pr'
suf = 'su'
num = 2
print(add_prefix_suffix(a, pre, suf, num))  # Output: 'prprtestsusu'
