

def calculate_only(lista):
    novalista = []
    for i in lista:
        if i % 3 == 0:
            i = i**2
            novalista.append(i)
        else:
            pass
    print(sum(novalista))


calculate_only([1,2,3,4,5,6,7,8,9])
    