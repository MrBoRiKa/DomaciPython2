

def check_highest_number(number):
    
    lista = []
    for i in str(number):
        lista.append(i)
    
    maximum = max(lista)
    minimum = min(lista)
    print(f'Maksimalna cifra u broju {number} je : {maximum}, a minimum je : {minimum}')



check_highest_number(385)