
def is_leap_year(year):
    if (year % 100 != 0 and year % 4 == 0) or (year % 400 ==0):
        print(f'{year} godina je prestupna.')
    else:
        print(f'{year} nije prestupnna godina.')




is_leap_year(2024)