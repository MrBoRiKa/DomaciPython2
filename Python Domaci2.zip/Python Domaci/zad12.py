
def do_if(broj):
    
    prva_cifra = broj //10
    druga_cifra = broj % 10 
    if prva_cifra > druga_cifra:
        razlika = prva_cifra - druga_cifra
        print(razlika)
    elif prva_cifra < druga_cifra:
        zbir = prva_cifra+druga_cifra
        print(zbir)
    else:
        proizvod = prva_cifra* druga_cifra
        print(proizvod)
    

    do_if(25)
