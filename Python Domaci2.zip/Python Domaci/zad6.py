def provjera(x,y):
    if y == 2*x+5 :
        print('Pcela moze da se krece po zici')
    else:
        print('Pcela ne moze da se krece po zici')

provjera(5,15)
provjera(-5,3)
provjera(0,3)
