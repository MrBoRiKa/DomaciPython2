

def check_if_string(string):
    vowels = ['a','e','i','o','u']
    if any(char in vowels for char in string):
        print('Ima samoglasnik.')
    else:
            print('Nema.')


check_if_string('Crnac')
check_if_string('Crnc')