# Get user input
s = input("Enter a string of positive and negative numbers: ")

# Initialize counter for single-digit negative numbers
count = 0

# Iterate over each character in the string
for i in range(len(s)):

    # If the character is a negative sign, check if the next character is a digit
    if s[i] == "-" and i < len(s) - 1 and s[i+1].isdigit():

        # If the next character is a digit, check if it is a single-digit negative number
        if int(s[i+1]) < 10:
            count += 1

# Print the result
print("Number of single-digit negative numbers: ", count)