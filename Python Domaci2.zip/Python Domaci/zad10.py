poluprecnik = 4
precnik = poluprecnik*2

def check_if_arrow(x1,y1):
    cilj = (x1**2 + y1**2)**0.5
    global precnik
    if cilj <= precnik:
        print('Strelica je pogodila pikado')
    else:
        print('Strelica nije pogodila pikado.')


result = check_if_arrow(5,5)
print(result)