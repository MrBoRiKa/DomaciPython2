

def make_rec(a,b):
    if a // 8 > 1:
        print(f'Mogu se napraviti vise kvadrata.')
    elif a % 8 == 0:
        print(f'Mogu se napraviti dva kvadrata.')
    else:
        print(f'Ne mogu se napraviti dva kvadrata.')

make_rec(8,2)