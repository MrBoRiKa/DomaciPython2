lista = []


def get_cifre(string):
    global lista
    brojevi = '1234567890'
    for x in string:
        if x in brojevi:
            lista.append(x)
    return lista


def calculate(lista):
    poc_vrijednost = 1
    for digit in lista:
        poc_vrijednost *= int(digit)

    print(poc_vrijednost)

    return poc_vrijednost


get_cifre('12345')

calculate(lista)