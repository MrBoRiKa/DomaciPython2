
def uvecati_vece_plate(lista_plati,povecanje):
    average = sum(lista_plati) / len(lista_plati)
    novalista_plati = []
    for i in lista_plati:
        if i > average :
            i += povecanje
            novalista_plati.append(i)
        else:
            novalista_plati.append(i)


    print (novalista_plati)

uvecati_vece_plate([100,200,300,200,300,400,500,100,200],100)
    
