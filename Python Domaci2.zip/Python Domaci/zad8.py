lista_oc= [5,4,3,2,5,3,4,5]
zbir_predmeta = len(lista_oc)
zbir_ocjena = sum(lista_oc)

def prosjek():
    global zbir_ocjena ,zbir_predmeta,lista_oc

    prosjecna_oc = zbir_ocjena / zbir_predmeta
    
    if 1 in lista_oc:
        print('Vas uspjeh je nedovoljan')
    elif prosjecna_oc >= 4.5 :
        print('Vas uspjeh je odlican')
    elif prosjecna_oc >= 3.5 and prosjecna_oc <4.5:
        print('Vas uspjeh je vrlodobar')
    elif prosjecna_oc >= 2.5 and prosjecna_oc < 3.5:
        print('Vas uspjeh je dobar.')
    elif prosjecna_oc >= 2 and prosjecna_oc< 2.5:
        print('Vas uspjeh je dovoljan')
    else:
        pass

prosjek()
