

def check_if_hex(string):
    count = 0
    for i in range(len(string)-1):
        currentnum = string[i]
        nextnum = string[i + 1]

        if currentnum.startswith('0') and nextnum.startswith('x') :
            count += 1 
    print(count)

check_if_hex('12 0x1A 0001 121 0x2')