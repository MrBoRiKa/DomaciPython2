def obradi_dvocifreni_broj(broj):
    prva_cifra = broj // 10
    druga_cifra = broj % 10

    if prva_cifra > druga_cifra:
        rezultat = prva_cifra - druga_cifra
        print(f"Razlika prve i druge cifre je: {rezultat}")
    elif prva_cifra < druga_cifra:
        rezultat = prva_cifra + druga_cifra
        print(f"Zbir prve i druge cifre je: {rezultat}")
    else:
        rezultat = prva_cifra * druga_cifra
        print(f"Proizvod cifara je: {rezultat}")
        

broj = 47

# Poziv funkcije za obradu dvocifrenog broja
obradi_dvocifreni_broj(broj) 