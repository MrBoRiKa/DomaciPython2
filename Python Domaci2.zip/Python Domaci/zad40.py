
#privr u funkciji je privremena lista, a moze biti i vrijednost i druge vrste podataka.

def calculate_abs(*args):
    privr = []
    for i in args:
        if int(i) % 2 == 0:
            if int(i) < 0:
                privr += str(abs(int(i)))
    new_privr = int(privr[0]) + int(privr[1])
    print(new_privr)

                
                
calculate_abs('-2','2','3','2','-3','-4')