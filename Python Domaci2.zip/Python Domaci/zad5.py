
import math

def is_able (a,b,c):
    if not a<0 or b<0 or c < 0:
        print('Moze da se napravi basta')
    else:
        print('Ne moze da se napravi basta')

is_able(2,1,3)