import math

def check_pol(r1,r2):
        
        obim1 = round( 2*r1 * math.pi) 
        obim2 = round(2*r2*math.pi)
        povrsina1 = math.pi * r1**2 
        povrsina2 = math.pi * r2**2

        if povrsina1 > povrsina2 :
                print(f'Obim veceg stola je:{obim1}')
        else:
            print(f'Obim veceg stola je:{obim2}')

r1,r2 = 5,6

print(check_pol(r1,r2))