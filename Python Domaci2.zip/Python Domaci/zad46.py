

def check_second_best_paycheck(lista_playa):
    lista_playa.sort(reverse = True)
    print(f'Druga najveca plata zaposlenom je :{lista_playa[1]} ')
    return lista_playa[1]


lista_plata = [600,900,700,200,300]
check_second_best_paycheck(lista_plata)