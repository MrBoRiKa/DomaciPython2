


def binary_check(string):
    for char in string:
        if char != '0' and char != '1':
            print('String nije binarni broj.')
            return
    print('String je binarni broj.')


binary_check('nige101')
