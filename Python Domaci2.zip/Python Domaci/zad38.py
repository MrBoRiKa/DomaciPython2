


def enkript():
    s = input('Unesite tekst')
    lista = ''
    for i in s :
        if int(i) % 2 ==0:
            lista += '1'
        elif int(i) % 2 != 0:
            lista += '0'

    print ( lista)
    return lista


enkript()