

def calculate_grades(lista_ucenika):
    trojke = 0
    cetvorke = 0
    petice = 0
    for ucenik, grade in lista_ucenika.items():
        if grade == 3:
            trojke += 1
        elif grade == 4:
            cetvorke += 1
        else:
            petice += 1
    print(f"{petice} ucenika imaju peticu,a {cetvorke} ucenika imaju cetvorku i {trojke} ucenika imaju troju")


calculate_grades({"pavle": 3,"ma": 4,"nikola": 4,"marko": 5,"ne": 5,"andrija": 4, "andrea": 3,"Milica":4}) 


#Program samo prima kljuceve koji imaju razlicitu vrijednost kljuca tj. "marko":5 ,"marko":3 . Cita kao marko:5 iz razloga sto je vec jednom napravio varijablu marko


    