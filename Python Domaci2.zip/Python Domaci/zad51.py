




def is_pass_stronch(password):
    password_privr = ''
    if len(password)>= 8 and any(password.isupper()) == True and password.islower() == True:
        for i in password:
            if i.ischar:
                continue
        print('YES')
    else:
        print('NO')
                

is_pass_stronch('Black1234')