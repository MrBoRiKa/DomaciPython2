

def is_narcissistic(broj):
    privr = 0
    duzina = len(broj)
    for i in broj:
       stepen =  int(i)** duzina
       privr += stepen
        
    if  str(privr) == broj:
        print('Da')
    else:
        print('Ne')

    return privr



is_narcissistic('1633')