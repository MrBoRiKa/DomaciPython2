def check_if(broj):
    broj = str(broj)
    
    
    if broj.startswith('0b'):
        print('Binarni')
    elif broj.startswith('0o'):
        print('Oktalni')
    elif broj.startswith('0x'):
        print('Heksadecimalni')
    else:
        print('Dekadni')
    

check_if('0b010')