


def get_vowels(string):
    vowels = ['a','e','i','o','u']
    word_without = ''
    for char in string:
        if char in vowels:
            word_without += char
        else:
            continue
    
    print(word_without)
    return word_without

get_vowels('abeceda')