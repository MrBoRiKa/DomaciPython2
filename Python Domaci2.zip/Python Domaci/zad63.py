

def which_longest(string):
    current = string.split()
    lista = ''
    for i in current:
        if len(i) > len(lista):
            lista = i

    print(lista)

which_longest('Ja sam crnac')        
