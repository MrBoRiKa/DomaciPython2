def what_agreg_is(celsius):
    if celsius < 100 and celsius > 0:
        print(f'Agregatno stanje je tecno.')
    elif celsius < 0 :
        print(f'Agregatno stanje je cvrsto')
    else:
        print(f'Agregatno stanje je gasovito.')

what_agreg_is(120) 