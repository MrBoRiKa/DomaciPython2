

def sum_min_max(number):
    number = str(number)
    lista = []
    for i in number:
        lista.append(int(i))
    
    min_num = min(lista)
    max_num = max(lista)
    calculate = min_num + max_num
    print(calculate)
sum_min_max(123)